project                 : Deploy a Static Website on AWS
Bucket website endpoint :http://my-430056679773-bucket.s3-website-us-east-1.amazonaws.com
Distribution Domain name: d2cpwnn64zzba6.cloudfront.net
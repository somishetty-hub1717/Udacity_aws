project                 : Deploy a Static Website on AWS
Bucket website endpoint :http://my-430056679773-bucket.s3-website-us-east-1.amazonaws.com
CloudFront URL: d1c2x86q8mt3kx.cloudfront.net